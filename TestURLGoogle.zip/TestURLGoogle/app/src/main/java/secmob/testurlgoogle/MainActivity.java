package secmob.testurlgoogle;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.net.MalformedURLException;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            WebService le_service = new WebService();
            String le_resultat = le_service.getText();

            TextView le_text;

            le_text = (TextView)findViewById(R.id.textView_web);
            le_text.setText(le_resultat);

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
}
