package secmob.testurlgoogle;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;


public class MainActivity extends AppCompatActivity {
    Context cont;
    ArrayList<Map<String, String>> lesLivres = new ArrayList<Map<String, String>>();
    SimpleAdapter adapter;
    ListView livres;
    List<Livre> le_resultat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adapter = new SimpleAdapter(this, lesLivres, R.layout.item_livre,
                new String[]{"titre", "ean", "type", "auteur", "editeurs", "categorie", "datePub", "langue", "resume"},
                new int[]{R.id.titre, R.id.ean, R.id.type, R.id.auteur, R.id.editeurs, R.id.categorie, R.id.datePub, R.id.langue, R.id.resume});
        livres = (ListView) findViewById(R.id.Liste_Livres);
        livres.setAdapter(adapter);

        try {
            WebService le_service = new WebService();

            if(ContextCompat.checkSelfPermission(cont,"android.permission.INTERNET") == PERMISSION_GRANTED){
                List<Livre> le_resultat = le_service.getLivres();
            }else{
                if(ActivityCompat.shouldShowRequestPermissionRationale(this,"android.permission.INTERNET")){
                    List<Livre> le_resultat = le_service.getLivres();
                }else{
                    Toast toast = Toast.makeText(cont, "Vous n'avez pas autorisé l'accès à internet !", Toast.LENGTH_LONG);
                    toast.show();
                }
            }


            if(le_resultat.isEmpty()){
                Toast.makeText(this.getBaseContext(), "Oups ca ne marche pas... :'(", Toast.LENGTH_LONG).show();
            }else{
                for (Livre livre: le_resultat){
                    addItem(livre.getTitre(), livre.getEan(), livre.getType(), livre.getAuteur(), livre.getEditeurs(), livre.getCategorie(), livre.getDatePub(), livre.getLangue(), livre.getResume());
                }
            }

            adapter.notifyDataSetChanged();

        }catch (Exception e){
            Log.e("Main : ", e.toString());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        lesLivres.clear();
        livres = (ListView) findViewById(R.id.Liste_Livres);

        WebService le_service = new WebService();
        List<Livre> le_resultat = le_service.getLivres();
        for (Livre livre : le_resultat){
            addItem(livre.getTitre(), livre.getEan(), livre.getType(), livre.getAuteur(), livre.getEditeurs(), livre.getCategorie(), livre.getDatePub(), livre.getLangue(), livre.getResume());
        }
        adapter.notifyDataSetChanged();
    }

    private void addItem(String titre, int ean, int type, String auteur, String editeurs, String categorie, int datePub, String langue, String resume) {
        HashMap<String,String> item = new HashMap<String,String>();
        item.put("titre", titre);
        item.put("ean", String.valueOf(ean));
        item.put("type", String.valueOf(type));
        item.put("auteur", auteur);
        item.put("editeurs", editeurs);
        item.put("categorie", categorie);
        item.put("datePub", String.valueOf(datePub));
        item.put("langue", langue);
        item.put("resume", resume);
        lesLivres.add(item);
    }


}
