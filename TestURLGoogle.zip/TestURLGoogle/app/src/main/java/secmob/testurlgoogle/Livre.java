package secmob.testurlgoogle;

/**
 * Created by Kiki on 23/03/2017.
 */

public class Livre {
    private String titre;           //items/volumeInfo/title
    private int ean;                //items/volumeInfo/
    private int type;
    private String auteur;          //items/volumeInfo/authors
    private String editeurs;        //items/volumeInfo/publisher
    private String categorie;
    private int datePub;            //items/volumeInfo/publishedDate
    private String langue;          //items/volumeInfo/industryIdentifiers/identifier avec "type": "ISBN_13"
    private String resume;          //items/volumeInfo/description

    public Livre() {
    }

    public Livre(String titre, int ean, String auteur, String editeurs, int datePub, String langue, String resume) {
        this.titre = titre;
        this.ean = ean;
        this.type = 0;
        this.auteur = auteur;
        this.editeurs = editeurs;
        this.categorie = "";
        this.datePub = datePub;
        this.langue = langue;
        this.resume = resume;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public int getEan() {
        return ean;
    }

    public void setEan(int ean) {
        this.ean = ean;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getAuteur() {
        return auteur;
    }

    public void setAuteur(String auteur) {
        this.auteur = auteur;
    }

    public String getEditeurs() {
        return editeurs;
    }

    public void setEditeurs(String editeurs) {
        this.editeurs = editeurs;
    }

    public String getCategorie() {
        return categorie;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public int getDatePub() {
        return datePub;
    }

    public void setDatePub(int datePub) {
        this.datePub = datePub;
    }

    public String getLangue() {
        return langue;
    }

    public void setLangue(String langue) {
        this.langue = langue;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }
}
