package secmob.testurlgoogle;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/**
 * Created by Kiki on 21/03/2017.
 */

public class WebService {
    private final String url = "https://www.googleapis.com/books/v1/volumes?q=isbn:9782070541270";
    Gson gson;


    public WebService() {
        gson = new Gson();
    }


    private InputStream sendRequest(URL url) throws Exception {
        try {
            // Ouverture de la connexion
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();

            // Connexion à l'URL
            urlConnection.connect();
            //Ca beug ici


            // Si le serveur nous répond avec un code OK
            if (urlConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                return urlConnection.getInputStream();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public List<Livre> getLivres() {
        try {
            // Envoi de la requête
            InputStream inputStream = sendRequest(new URL(url));

            // Vérification de l'inputStream
            if(inputStream != null) {
                // Lecture de l'inputStream dans un reader
                InputStreamReader reader = new InputStreamReader(inputStream);

                // Retourne la liste désérialisée par le moteur GSON
                return gson.fromJson(reader, new TypeToken<List<Livre>>(){}.getType());
            }

        } catch (Exception e) {
            Log.e("WebService", "Impossible de rapatrier les données...");
        }
        return null;
    }
}
